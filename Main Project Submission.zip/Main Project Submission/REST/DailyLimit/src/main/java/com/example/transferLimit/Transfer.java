package com.example.transferLimit;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Entity
@Table(name = "transfers")
public class Transfer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "customer_identifier", nullable = false)
    private Integer customerIdentifier;

    @Column(name = "transfer_amount", nullable = false)
    private BigDecimal transferAmount;

    @Column(name = "transfer_time", nullable = false)
    private Timestamp transferTime;

    // Constructors
    public Transfer() {
    }

    public Transfer(Integer customerIdentifier, BigDecimal transferAmount, Timestamp transferTime) {
        this.customerIdentifier = customerIdentifier;
        this.transferAmount = transferAmount;
        this.transferTime = transferTime;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public Integer getCustomerIdentifier() {
        return customerIdentifier;
    }

    public void setCustomerIdentifier(Integer customerIdentifier) {
        this.customerIdentifier = customerIdentifier;
    }

    public BigDecimal getTransferAmount() {
        return transferAmount;
    }

    public void setTransferAmount(BigDecimal transferAmount) {
        this.transferAmount = transferAmount;
    }

    public Timestamp getTransferTime() {
        return transferTime;
    }

    public void setTransferTime(Timestamp transferTime) {
        this.transferTime = transferTime;
    }

}