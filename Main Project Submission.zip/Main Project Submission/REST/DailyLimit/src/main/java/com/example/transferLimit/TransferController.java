package com.example.transferLimit;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/transfer")
public class TransferController {
    @Autowired
    private TransferCheckService service;

    @GetMapping("/can-transfer")
    public ResponseEntity<Boolean> canTransfer(
            @RequestParam Integer customerId,
            @RequestParam BigDecimal amount) {
        boolean allowed = service.canTransfer(customerId, amount);
        return ResponseEntity.ok(allowed);
    }

    // @PostMapping("/perform-transfer") // For actual transfers
    // public ResponseEntity<String> performTransfer(
    // @RequestParam Integer customerId,
    // @RequestParam BigDecimal amount) {

    // if (service.performTransfer(customerId, amount)) {
    // return ResponseEntity.ok("Transfer completed successfully");
    // }
    // return ResponseEntity.badRequest().body("Transfer rejected");
    // }
}