package com.example.transferLimit; // adjust to your package

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerApplication { // your main class name

    public static void main(String[] args) {
        SpringApplication.run(CustomerApplication.class, args);
    }
}
