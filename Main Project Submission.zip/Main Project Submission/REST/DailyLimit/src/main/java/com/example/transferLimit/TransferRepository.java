package com.example.transferLimit;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TransferRepository extends JpaRepository<Transfer, Long> {

        @Query("SELECT COALESCE(SUM(t.transferAmount), 0) FROM Transfer t " +
                        "WHERE t.customerIdentifier = :customerId " +
                        "AND t.transferTime >= :since")
        Integer sumTransfersSince(@Param("customerId") Integer customerId,
                        @Param("since") Timestamp since);

        @Query("SELECT t.transferTime FROM Transfer t " +
                        "WHERE t.customerIdentifier = :customer_identifier " +
                        "ORDER BY t.transferTime DESC LIMIT 1")
        Timestamp findLastTransferTime(@Param("customer_identifier") Integer customer_identifier);

        @Query("SELECT COALESCE(SUM(t.transferAmount), 0) FROM Transfer t " +
                        "WHERE t.customerIdentifier = :customerId " +
                        "AND t.transferTime >= :timeLimit")
        BigDecimal sumTransfersInLastFiveMinutes(@Param("customerId") Integer customerId,
                        @Param("timeLimit") LocalDateTime timeLimit);

}