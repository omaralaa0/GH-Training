package com.example.transferLimit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;

@Service
public class TransferCheckService {

    @Autowired
    private CustomerRepository customerRepo;

    @Autowired
    private TransferRepository transferRepo;

    @Transactional
    @GetMapping("/can-transfer")
    public boolean canTransfer(@RequestParam("customerId") Integer customerId,
            @RequestParam("amount") BigDecimal amount) {
        Customer customer = customerRepo.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        LocalDateTime fiveMinutesAgo = LocalDateTime.now().minusMinutes(5);

        BigDecimal recentTotal = transferRepo.sumTransfersInLastFiveMinutes(customerId, fiveMinutesAgo);

        BigDecimal dailyLimit = BigDecimal.valueOf(customer.getDailyLimit());

        if (recentTotal.add(amount).compareTo(dailyLimit) <= 0) {

            return true;
        } else {
            return false;
        }
    }
}
