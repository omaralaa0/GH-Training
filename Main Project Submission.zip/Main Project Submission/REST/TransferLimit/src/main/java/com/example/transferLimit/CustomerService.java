package com.example.transferLimit;

import com.example.transferLimit.Customer;
import com.example.transferLimit.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    public Integer getTransferLimitById(Integer id) {
        Optional<Customer> customer = customerRepository.findById(id);
        return customer.map(Customer::getTransferLimit).orElse(null);
    }
}
