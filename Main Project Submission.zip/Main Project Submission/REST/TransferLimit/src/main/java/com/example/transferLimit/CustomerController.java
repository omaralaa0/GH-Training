package com.example.transferLimit;

import com.example.transferLimit.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping("/transfer-limit/{id}")
    public Integer getTransferLimit(@PathVariable Integer id) {
        return customerService.getTransferLimitById(id);
    }
}
