--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-05-19 15:46:44

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 218 (class 1259 OID 123195)
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    customer_identifier integer NOT NULL,
    customer_name character varying(100),
    customer_balance double precision,
    customer_type character varying(10),
    transfer_limit integer,
    otp integer,
    daily_limit integer,
    CONSTRAINT customer_customer_type_check CHECK (((customer_type)::text = ANY ((ARRAY['vip'::character varying, 'normal'::character varying])::text[])))
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 123192)
-- Name: transfers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transfers (
    customer_identifier integer,
    beneficiary_account_number integer,
    transfer_amount numeric(38,2),
    transfer_time timestamp without time zone,
    id bigint NOT NULL,
    transfer_reason character varying(100),
    approval_type character varying(20)
);


ALTER TABLE public.transfers OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 131457)
-- Name: transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transfers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transfers_id_seq OWNER TO postgres;

--
-- TOC entry 4859 (class 0 OID 0)
-- Dependencies: 219
-- Name: transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transfers_id_seq OWNED BY public.transfers.id;


--
-- TOC entry 4699 (class 2604 OID 131458)
-- Name: transfers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers ALTER COLUMN id SET DEFAULT nextval('public.transfers_id_seq'::regclass);


--
-- TOC entry 4852 (class 0 OID 123195)
-- Dependencies: 218
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (customer_identifier, customer_name, customer_balance, customer_type, transfer_limit, otp, daily_limit) FROM stdin;
1	Ali	42500	vip	2000	881796	4000
2	Hassan	19500	normal	2000	720704	4000
3	Youssef	5000	vip	2000	\N	4000
4	Islam	5000	normal	2000	779238	4000
\.


--
-- TOC entry 4851 (class 0 OID 123192)
-- Dependencies: 217
-- Data for Name: transfers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transfers (customer_identifier, beneficiary_account_number, transfer_amount, transfer_time, id, transfer_reason, approval_type) FROM stdin;
1	2	1000.00	2025-05-19 04:40:53.967509	16	\N	\N
1	2	1000.00	2025-05-19 04:42:44.257133	17	\N	\N
1	2	1000.00	2025-05-19 14:08:13.378868	18	RENT	AUTOMATIC
1	2	2500.00	2025-05-19 15:11:20.297791	19	AYHAGA	Manual -Omar
1	2	2000.00	2025-05-19 15:34:51.103231	20	l	AUTOMATIC
1	2	2000.00	2025-05-19 15:36:07.774002	21	r	AUTOMATIC
1	2	1000.00	2025-05-19 15:37:08.647566	22	sdsd	man
\.


--
-- TOC entry 4860 (class 0 OID 0)
-- Dependencies: 219
-- Name: transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transfers_id_seq', 22, true);


--
-- TOC entry 4704 (class 2606 OID 123200)
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_identifier);


--
-- TOC entry 4702 (class 2606 OID 131460)
-- Name: transfers transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT transfers_pkey PRIMARY KEY (id);


--
-- TOC entry 4705 (class 2606 OID 123201)
-- Name: transfers fk_customer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT fk_customer FOREIGN KEY (customer_identifier) REFERENCES public.customer(customer_identifier);


-- Completed on 2025-05-19 15:46:44

--
-- PostgreSQL database dump complete
--

