package com.example.soap;

import javax.jws.WebMethod;
import javax.jws.WebService;

import javax.jws.WebParam;

@WebService(targetNamespace = "http://otp.new.namespace.com")
public interface OtpService {
    int generateOtp(@WebParam(name = "customerId") int customerId);
}
