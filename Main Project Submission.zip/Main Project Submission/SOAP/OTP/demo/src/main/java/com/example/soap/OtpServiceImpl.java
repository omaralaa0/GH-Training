package com.example.soap;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import java.sql.*;
import java.util.Random;

@WebService(endpointInterface = "com.example.soap.OtpService", targetNamespace = "http://otp.new.namespace.com")
public class OtpServiceImpl implements OtpService {

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/bankTransfers";
    private static final String DB_USER = "offers";
    private static final String DB_PASSWORD = "offers";

    @Override
    public int generateOtp(int customerId) {
        System.out.println("Attempting to connect to: " + DB_URL);

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            System.out.println("Connection successful!");

            String selectSql = "SELECT customer_identifier FROM customer WHERE customer_identifier = ?";
            try (PreparedStatement selectStmt = conn.prepareStatement(selectSql)) {
                selectStmt.setInt(1, customerId);
                System.out.println("Executing query: " + selectStmt.toString());

                ResultSet rs = selectStmt.executeQuery();
                if (rs.next()) {
                    int otp = 100000 + new Random().nextInt(900000);
                    System.out.println("Generated OTP for customer " + customerId + ": " + otp);

                    String updateSql = "UPDATE customer SET otp = ? WHERE customer_identifier = ?";
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                        updateStmt.setInt(1, otp);
                        updateStmt.setInt(2, customerId);

                        int rowsUpdated = updateStmt.executeUpdate();
                        System.out.println("OTP updated in database for customer " + customerId + ": Rows affected = "
                                + rowsUpdated);
                    }

                    return otp;
                } else {
                    System.out.println("Customer not found: " + customerId);
                    return -1;
                }
            }
        } catch (SQLException e) {
            System.err.println("Database error:");
            e.printStackTrace();
            return -2;
        }
    }

}
